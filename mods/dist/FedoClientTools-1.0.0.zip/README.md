# FedoClientTools

*By Fedo*

Client-only companion to [FedoServerTools](../FedoServerTools/README.md) — split out so
that a regular player only installs what actually runs on their own machine: skipping
the main menu straight to auto-connect, a small in-game clock, and a reconnect/quit
screen after a lost connection. No `ServerToken`, no admin routes, nothing that talks
to the API with a secret — safe to install on any player's client (and it's part of the
player-facing modpack, unlike FedoServerTools).

## Auto-join (client menu skip)

A client-only Harmony patch on `FejdStartup` (the Valheim main menu) that skips it
entirely when the active modpack profile has an auto-connect target configured (see the
Fedoheim launcher's "Profils" page, admin only). At boot, it reads a small
`fedoheim-session.txt` file dropped by the launcher next to `BepInEx/` — never part of
this mod's own package, never synced like the rest of a modpack.

- If the profile has no auto-connect target configured, this does nothing — the menu
  behaves exactly like vanilla Valheim.
- If the account has no character linked yet, it jumps straight to the "new character"
  screen, with the name field pre-filled to the player's Discord username as a
  suggestion — freely editable, not locked. Once the character is created, it connects
  automatically to the configured target (a local world to host, or a dedicated server
  to join).
- If the account already has a linked character (and it exists locally), the whole menu
  is skipped entirely: the character is selected and the game connects immediately.

The character↔account link itself is decided server-side (see FedoServerTools'
`PeerSteamId.cs` and the Fedoheim API's `linkCharacterName`), not by this patch — it
only reacts to what the launcher tells it, and never restricts what name a player
chooses.

Since none of the vanilla menu panels are shown once auto-join takes over, Valheim's own
loading screen never appears either — the whole connection/world-load time would
otherwise be a plain black screen with no text. `LoadingOverlay.cs` shows the Fedoheim
logo and a "Chargement de Fedoheim" line below it, both centered in the middle of the
screen, hidden as soon as the in-game HUD actually appears (or after 30s regardless, as
a safety net if the connection fails).

### Reconnect / quit screen

If auto-join brings the player back to this menu after a failed/lost connection
(`ZNet.GetConnectionStatus()` not `None`) rather than a first launch, `DisconnectChoiceOverlay.cs`
shows two buttons — "Connexion" (retry the same target) and "Quitter le jeu" — instead
of silently retrying in a loop. For a dedicated-server target, it also polls `GET
/modpacks/:slug/online-players` (public route, no token) every 10s to show a live
online/offline status and disable the reconnect button while the server is confirmed
offline.

## In-game clock

Shows a small clock (`HH:MM`) at the top-center of the screen, following the day/night
cycle (`EnvMan.GetDayFraction()` — the same value the game itself uses for lighting).
Works on any installation with a local player (client or host), purely local, no
network call involved.

**Draggable, position saved locally**: hold **Left Shift** and drag the clock with the
mouse to move it anywhere on screen. The clock is normally "click-through" (it never
intercepts a gameplay click at that spot on screen) — holding Shift is what makes it
draggable. The new position is written to `ClockPositionX`/`ClockPositionY` in this
installation's own `.cfg` as soon as you release the drag, and is restored on every
future launch — purely local, never synced through the modpack or the server.

## Configuration

Settings live in `BepInEx/config/fedo.clienttools.cfg`.

**[Api]**
- `ApiBaseUrl` — base URL of the Fedoheim API, no trailing slash (default
  `http://127.0.0.1:3000`). Only used to poll the public online-players route for the
  reconnect screen above — no login/token involved.

**[Time]**
- `ShowClockOverlay` (default `true`) — shows the in-game clock overlay.
- `TimeOffsetHours` (default `0`, between `-12` and `12`) — shifts the displayed clock
  if it doesn't match what the sky looks like. Purely cosmetic. Independent of
  FedoServerTools' own setting of the same name (not synced between the two mods).
- `ClockPositionX` / `ClockPositionY` (default `0` / `-18`) — where the overlay sits on
  screen. Written automatically when a player drags the clock; not meant to be
  hand-edited, but resettable here.

## Admin broadcast message (receiving side)

Receives and displays the admin broadcast message sent from FedoServerTools (see that
mod's README, "Admin server commands") — shows up centered on screen in yellow and in
the in-game chat. The RPC protocol itself (`mods/_shared/BroadcastMessage.cs`) is shared
between the two mods so they never drift on the RPC name/format.

## Stability patch (unrelated to any of the above)

Shared with FedoServerTools (`mods/_shared/ZNetSceneStabilityPatch.cs`) — a small,
generic Harmony patch on `ZNetScene.RemoveObjects` that repairs a class of Valheim bug
seen on heavily-tested/modded saves (a `ZNetView` destroyed without being properly
deregistered, which would otherwise crash that vanilla method every single frame,
forever). See FedoServerTools' README for the full explanation.
